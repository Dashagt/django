from django.apps import AppConfig


class WomenConfig(AppConfig):
    name = 'women'
    verbose_name = 'Жінки світу'
